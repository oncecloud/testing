from locust import HttpLocust, TaskSet, task
class UserBehavior(TaskSet):
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.login()

    def login(self):
        pass

    @task(25)
    def task1(self):
        self.client.get("/containers/json")

    @task(3)
    def task3(self):
        self.client.post("/containers/193e904e9921/start")
        self.client.post("/containers/e8bb006aa95b/start")
        self.client.post("/containers/0d28a7e83ef4/start")
        self.client.post("/containers/9b00fae23d5d/start")
        self.client.post("/containers/3cfef7f2d42f/start")

    @task(1)
    def task4(self):
        self.client.post("/containers/193e904e9921/stop")
        self.client.post("/containers/e8bb006aa95b/stop")
        self.client.post("/containers/0d28a7e83ef4/stop")
        self.client.post("/containers/9b00fae23d5d/stop")
        self.client.post("/containers/3cfef7f2d42f/stop")

    @task(1)
    def task6(self):
        self.client.get("/containers/193e904e9921/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/e8bb006aa95b/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/0d28a7e83ef4/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/9b00fae23d5d/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/3cfef7f2d42f/logs?stderr=1&stdout=1&timestamps=1&foll")

    @task(12)
    def task8(self):
        self.client.get("/images/json")

class WebsiteUser(HttpLocust):
    task_set = UserBehavior
    min_wait=4000
    max_wait=4000
