from locust import HttpLocust, TaskSet, task
class UserBehavior(TaskSet):
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.login()

    def login(self):
        pass

    @task(3)
    def task(self):
        self.client.post("/containers/36c6ba721e39/stop")
        self.client.post("/containers/f5d3287b8899/stop")
        self.client.post("/containers/7b355fed5936/stop")
        self.client.post("/containers/86fbce0ddb59/stop")
        self.client.post("/containers/482f8bdb5d2e/stop")
        self.client.post("/containers/d479286cdc50/stop")
        self.client.post("/containers/64a074db6591/stop")
        self.client.post("/containers/6550f9383064/stop")
        self.client.post("/containers/04c522030706/stop")
        self.client.post("/containers/79ccbb15af01/stop")

class WebsiteUser(HttpLocust):
    task_set = UserBehavior
    min_wait=4000
    max_wait=4000
