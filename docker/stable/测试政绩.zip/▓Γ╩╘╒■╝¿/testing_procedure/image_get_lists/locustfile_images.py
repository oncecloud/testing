from locust import HttpLocust, TaskSet, task
class UserBehavior(TaskSet):
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.login()

    def login(self):
        pass

    @task(12)
    def task8(self):
        self.client.get("/images/json")

class WebsiteUser(HttpLocust):
    task_set = UserBehavior
    min_wait=4000
    max_wait=4000
