#!/bin/bash
#hosts="197.3.84.237 197.3.84.238 197.3.84.239 197.3.155.154"
hosts="197.3.84.238 197.3.84.239 197.3.155.153 197.3.155.154 197.3.155.155"

echo "start minitor on registry"
ssh testdeploy@197.3.155.155 "./monitor.sh bond0 >> /tmp/monitor_log &"
ssh testdeploy@197.3.155.155 "sar 1 >> /tmp/cpu_log &"

sleep 10

for node in $hosts;do
    echo -e "`date +%k:%M:%S`"
    echo "Pull image form registry on $node:"
    docker -H tcp://$node:2375 pull 197.3.155.155:5000/test-registr &
done

for node in $hosts;do
    echo -e "`date +%k:%M:%S`"
    echo "Catch images list on $node"
#    while ["1"]; do ssh testdeploy@$node docker images ;done >> /tmp/images_log &
    while [ "1" ]; do docker -H tcp://$node:2375 images ;sleep 1;echo "===========================" ;done >> /tmp/images_log_$node &
done
#ssh testdeploy@197.3.84.238 docker -H tcp://197.3.84.237:2375 pull 197.3.155.155:5000/cmbc-test-registry &
