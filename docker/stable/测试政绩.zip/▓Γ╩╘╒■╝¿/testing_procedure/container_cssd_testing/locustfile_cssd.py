import random
from locust import HttpLocust, TaskSet, task
from locust.events import EventHook

class UserBehavior(TaskSet):
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.login()

    def login(self):
        pass

    global list1
    list1 = []
    stream1 = open("/tmp/containers_list", "r")
    for line1 in stream1.readlines():
        list1.append(line1[:-1])
    stream1.close()

    global list2
    list2 = []
    stream2 = open("/tmp/containers_stop_list", "r")
    for line2 in stream2.readlines():
        list2.append(line2[:-1])
    stream2.close()

    @task(10)
    def task1(self):
        json="""
        {
            "Hostname": "",
            "User": "",
            "Memory": 0,
            "MemorySwap": 0,
            "CpuShares": 512,
            "CpusetCpus": "0,1",
            "AttachStdin": false,
            "AttachStdout": true,
            "AttachStderr": true,
            "PortSpecs":null,
            "Tty": false,
            "OpenStdin": false,
            "StdinOnce": false,
            "Env": null,
            "Cmd": ["/bin/bash"],
            "Entrypoint": "",
            "Image": "stress3",
            "Tag":"latest",
            "Volumes": {
                 "/tmp": {}
            },
            "WorkingDir": "/bin",
            "NetworkDisabled": false,
            "ExposedPorts": {
                "22/tcp": {}}
        }
        """
        self.client.post("/containers/create", json, headers={"Content-Type": "application/json"})

    @task(10)
    def task2(self):
        cid=random.sample(list1,1)
        self.client.post("/containers/%s/start" % cid[0] )

    @task(5)
    def task3(self):
        cid=random.sample(list1,1)
        self.client.post("/containers/%s/stop" % cid[0] )

    @task(1)
    def task4(self):
        cid=random.sample(list2,1)
        self.client.delete("/containers/%s" % cid[0] )

    @task(20)
    def task5(self):
        self.client.get("/containers/json")

class WebsiteUser(HttpLocust):
    task_set = UserBehavior
    min_wait=10000
    max_wait=20000
