#!/usr/bin/python
import random

def main():
    stream = open("/tmp/containers_list", "r")
    list1 = []
    for line in stream.readlines():
        list1.append(line[:-1])
    stream.close()
    print list1
    id=random.sample(list1,1)
    print id[0]


if __name__ == "__main__":
    main()
