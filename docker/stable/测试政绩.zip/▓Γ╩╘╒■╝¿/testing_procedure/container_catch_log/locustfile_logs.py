from locust import HttpLocust, TaskSet, task
class UserBehavior(TaskSet):
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.login()

    def login(self):
        pass

    @task(1)
    def task6(self):
        self.client.get("/containers/36c6ba721e39/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/f5d3287b8899/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/7b355fed5936/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/86fbce0ddb59/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/482f8bdb5d2e/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/d479286cdc50/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/64a074db6591/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/6550f9383064/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/04c522030706/logs?stderr=1&stdout=1&timestamps=1&foll")
        self.client.get("/containers/79ccbb15af01/logs?stderr=1&stdout=1&timestamps=1&foll")

class WebsiteUser(HttpLocust):
    task_set = UserBehavior
    min_wait=4000
    max_wait=4000
