from locust import HttpLocust, TaskSet, task
from locust.events import EventHook
class UserBehavior(TaskSet):
    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.login()

    def login(self):
        pass
    global json
    json="""
    {
        "Hostname": "",
        "User": "",
        "Memory": 0,
        "MemorySwap": 0,
        "CpuShares": 512,
        "CpusetCpus": "0,1",
        "AttachStdin": false,
        "AttachStdout": true,
        "AttachStderr": true,
        "PortSpecs":null,
        "Tty": false,
        "OpenStdin": false,
        "StdinOnce": false,
        "Env": null,
        "Cmd": ["/bin/bash"],
        "Entrypoint": "",
        "Image": "stress3",
        "Tag":"latest",
        "Volumes": {
             "/tmp": {}
        },
        "WorkingDir": "/bin",
        "NetworkDisabled": false,
        "ExposedPorts": {
            "22/tcp": {}}
    }
    """

    @task(1)
    def task1(self):
        self.client.post("/containers/create", json, headers={"Content-Type": "application/json"})

class WebsiteUser(HttpLocust):
    task_set = UserBehavior
    min_wait=10000
    max_wait=10000
